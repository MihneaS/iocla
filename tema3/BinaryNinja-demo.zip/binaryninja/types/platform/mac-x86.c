#define LIBC(x) _##x
#include "posix.c"
